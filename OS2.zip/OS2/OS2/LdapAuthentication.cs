﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.DirectoryServices;
using System.Text;
using System.Globalization;
using System.Security.Principal;
using System.Threading;

namespace OS2
{
    public class LdapAuthentication
    {
        private string _path;


        public LdapAuthentication(string path)
        {
            _path = path;
            SetCultureAndIdentity();
        }

        public static void SetCultureAndIdentity()
        {
            AppDomain.CurrentDomain.SetPrincipalPolicy(PrincipalPolicy.WindowsPrincipal);
            WindowsPrincipal principal = (WindowsPrincipal)Thread.CurrentPrincipal;
            WindowsIdentity identity = (WindowsIdentity)principal.Identity;
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
        }

        public bool IsAuthenticated(string dominio, string user, string pass)
        {
            string domainAndUsername = dominio + @"\" + user;
            DirectoryEntry entry = new DirectoryEntry(_path, domainAndUsername, pass, AuthenticationTypes.Secure);
            try
            {
                // Bind to the native AdsObject to force authentication. 
                Object obj = entry.NativeObject;
                DirectorySearcher search = new DirectorySearcher(entry);
                search.Filter = "(SAMAccountName=" + user + ")";
                search.PropertiesToLoad.Add("CN");
                SearchResult result = search.FindOne();
                if (result == null)
                {
                    return false;
                }




            }
            catch (Exception ex)
            {
                throw new Exception("Error autenticacion de usuario. " + ex.Message);
            }
            return true;
        }

        public Usuario getInfoUser(string dominio, string user, string pass)
        {
            string domainAndUsername = dominio + @"\" + user;
            DirectoryEntry entry = new DirectoryEntry(_path, domainAndUsername, pass, AuthenticationTypes.Secure);
            Usuario usuario = new Usuario();
            try
            {
                DirectorySearcher ds = null;
                ds = new DirectorySearcher(entry);
                ds.PropertiesToLoad.Add("givenName");
                ds.PropertiesToLoad.Add("sn");
                ds.PropertiesToLoad.Add("displayName");
                ds.Filter = "(&(objectCategory=User)(objectClass=person)(name=" + user + "*))";
                SearchResult result;
                result = ds.FindOne();
                if (result != null)
                {
                    //ResultPropertyCollection props = result.Properties;
                    //StringBuilder sb = new StringBuilder("");
                    //foreach (string propName in props.PropertyNames)
                    //{
                    //    if (result.Properties[propName][0] != null)
                    //    {
                    //        sb.Append(propName + " = " + result.Properties[propName][0].ToString());
                    //    }
                    //    else
                    //    {
                    //        sb.Append(propName + " = NULL");
                    //    }
                    //    sb.Append("\n");
                    //}
                    usuario.firshName = result.Properties["givenName"][0].ToString();
                    usuario.lastName = result.Properties["sn"][0].ToString();
                    usuario.displayName = result.Properties["displayName"][0].ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return usuario;
        }

        public string GetGroups(string dominio, string user, string pass)
        {
            StringBuilder groupNames = new StringBuilder();
            string domainAndUsername = dominio + @"\" + user;
            DirectoryEntry entry = new DirectoryEntry(_path, domainAndUsername, pass, AuthenticationTypes.Secure);
            try
            {
                DirectorySearcher ds = null;
                ds = new DirectorySearcher(entry);
                ds.PropertiesToLoad.Add("memberOf");
                ds.Filter = "(&(objectCategory=User)(objectClass=person)(name=" + user + "*))";
                SearchResult result;
                result = ds.FindOne();
                if (result != null)
                {
                    int propertyCount = result.Properties["memberOf"].Count;
                    String dn;
                    int equalsIndex, commaIndex;
                    for (int propertyCounter = 0; propertyCounter < propertyCount;
                      propertyCounter++)
                    {
                        dn = (String)result.Properties["memberOf"][propertyCounter];
                        equalsIndex = dn.IndexOf("=", 1);
                        commaIndex = dn.IndexOf(",", 1);
                        if (-1 == equalsIndex)
                        {
                            return null;
                        }
                        groupNames.Append(dn.Substring((equalsIndex + 1),
                        (commaIndex - equalsIndex) - 1));
                        groupNames.Append("|");
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error obtaining group names. " + ex.Message);
            }
            return groupNames.ToString();
        }

        public bool CambiarContraseña(string dominio, string user, string pass, string contraseñaNueva)
        {
            string domainAndUsername = dominio + @"\" + user;
            DirectoryEntry entry = new DirectoryEntry(_path, domainAndUsername, pass, AuthenticationTypes.Secure);
            DirectoryEntry userEntry = new DirectoryEntry();
            try
            {
                object obj = entry.NativeObject;
                DirectorySearcher search = new DirectorySearcher(entry);
                search.Filter = "(SAMAccountName=" + user + ")";
                search.SearchScope = SearchScope.Subtree;
                search.CacheResults = false;

                SearchResultCollection results = search.FindAll();

                foreach (SearchResult result in results)
                {
                    userEntry = result.GetDirectoryEntry();
                    break;
                }

                if (userEntry != null)
                {
                    //userEntry.UsePropertyCache = true;
                    userEntry.Invoke("SetPassword", new object[] { contraseñaNueva });
                    userEntry.Properties["LockOutTime"].Value = 0;
                    //userEntry.Invoke("ChangePassword", new object[] { pass, contraseñaNueva });
                    userEntry.CommitChanges();
                    userEntry.Close();
                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {
                throw new Exception("No se pudo cambiar la contraseña. " + ex.Message);
            }

            return true;
        }


        public List<Usuario> Lista_User(string ldap, string userAD, string passAD)
        {

            string strSearchAD = "";
            List<Usuario> listUsuarios = new List<Usuario>();
            DirectoryEntry adEntry = new DirectoryEntry("LDAP://carcamoOS.com/DC=carcamoOS,DC=com", "user", "pass", AuthenticationTypes.Secure);
            System.DirectoryServices.DirectorySearcher adSearch = new System.DirectoryServices.DirectorySearcher(adEntry);


            adSearch.Filter = "(&(objectClass=user)" + strSearchAD + ")";

            SearchResultCollection objResultados;
            SearchResult adResult;

            adResult = adSearch.FindOne(); // if only i need the first returned user 
            objResultados = adSearch.FindAll();

            foreach (SearchResult MiObjeto in objResultados)
            {
                Usuario usarioToAdd = new Usuario();
                usarioToAdd.mail = MiObjeto.Properties["mail"][0].ToString();
                usarioToAdd.login = MiObjeto.Properties["sAMAccountName"][0].ToString();
                usarioToAdd.firshName = MiObjeto.Properties["givenName"][0].ToString();
                usarioToAdd.lastName = MiObjeto.Properties["sn"][0].ToString();
                listUsuarios.Add(usarioToAdd);
            }
            return listUsuarios;


        }

    }
}