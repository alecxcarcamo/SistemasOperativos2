﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace OS2
{
    public partial class Iniciado : System.Web.UI.Page
    {
        Usuario user = new Usuario();
        string Group;
        string adPath = ("LDAP://172.31.31.167/DC=carcamoOS,DC=com");
        string Username;
        string Pass;

        protected void Page_Load(object sender, EventArgs e)
        {
            user = (Usuario)Session["us"];
            Group = Session["grupos"].ToString();
            Username = Session["user"].ToString();
            Pass = Session["pass"].ToString();
            if (!IsPostBack)
                btnGeneral_Click(sender, e);
            lblError.Text = "";
        }

        protected void btnGeneral_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 0;
            lblFirstName.Text = user.firshName;
            lblLastName.Text = user.lastName;
            lblDisplayName.Text = lblFirstName.Text + " " + lblLastName.Text;
        }

        protected void btnMemberOf_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 1;
            lblMemberOf.Text = Group;
        }

        protected void btnCambiarContraseña_Click(object sender, EventArgs e)
        {
            ///string ContraseñaNueva = Microsoft.VisualBasic.Interaction.InputBox("Ingrese su contraseña Nueva", "Contraseña Nueva", "New Password");
            // LdapAuthentication ldap = new LdapAuthentication(adPath);
            MultiView1.ActiveViewIndex = 2;
            lblContra.InnerText = Pass;
        }

        protected void CambiarContra_Click(object sender, EventArgs e)
        {
            string ContraseñaNueva = Microsoft.VisualBasic.Interaction.InputBox("Ingrese su contraseña Nueva", "Contraseña Nueva", "New Password");
             LdapAuthentication ldap = new LdapAuthentication(adPath);
       
            String contraNueva = txtContraNueva.Value;
            try
            {
                LdapAuthentication adAuth = new LdapAuthentication(adPath);
                String dominio = Session["dominio"].ToString();
                if (adAuth.CambiarContraseña(dominio, Username, Pass, contraNueva))
                {
                    Pass = contraNueva;
                    lblError.Text = "Contraseña cambiada!";
                    lblError.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    lblError.Text = "Error al cambiar contraseña!";
                    lblError.ForeColor = System.Drawing.Color.Red;
                }
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.ForeColor = System.Drawing.Color.Red;
            }
            
         
    }

        

        protected void MultiView1_ActiveViewChanged(object sender, EventArgs e)
        {

        }

        protected void btnCerrarSecion_Click(object sender, EventArgs e)
        {
            Response.Redirect("Logon.aspx");
        }
    }
}