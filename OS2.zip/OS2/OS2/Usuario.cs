﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OS2
{
    public class Usuario
    {
        public string firshName
        {
            get;
            set;
        }
        public string lastName
        {
            get;
            set;
        }

        public string displayName
        {
            get;
            set;
        }
        public string mail
        {
            get;
            set;
        }

        public string login
        {
            get;
            set;
        }



    }
}