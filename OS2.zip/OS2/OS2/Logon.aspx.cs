﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace OS2
{
    public partial class Logon : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string dominio, user, pass;
            bool correcto = false;
            dominio = Domain.Text;
            user = Username.Text;
            pass = Password.Text;

            string adPath = ("LDAP://172.31.31.167/DC=carcamoOS,DC=com");

            LdapAuthentication adAuth = new LdapAuthentication(adPath);

            try
            {
                if (true == adAuth.IsAuthenticated(dominio, user, pass))
                {

                    Iniciado ini = new Iniciado();
                    Object o = new object();
                    Usuario us = new Usuario();
                    us = adAuth.getInfoUser(dominio, user, pass);
                    string grupos = adAuth.GetGroups(dominio, user, pass);

                    Session["us"] = us;
                    Session["grupos"] = grupos;
                    Session["user"] = user;
                    Session["pass"] = pass;
                    Session["dominio"] = dominio;
                    correcto = true;
                }
                else
                {
                    lblError.Text =
                    "No Logeado";
                    correcto = false;
                }
            }
            catch (Exception ex)
            {
                lblError.Text = "Error de Logeo" + ex.Message;
                correcto = false;
            }
            if (correcto)
                Response.Redirect("Iniciado.aspx");

        }

        protected void Username_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Password_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Domain_TextChanged(object sender, EventArgs e)
        {

        }
    }
}